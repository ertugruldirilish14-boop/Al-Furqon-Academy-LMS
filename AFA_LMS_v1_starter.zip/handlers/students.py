from aiogram import Router
from aiogram.types import CallbackQuery
from database import connect
router=Router()
@router.callback_query(lambda c:c.data=="groups")
async def groups(c:CallbackQuery):
    db=connect(); rows=db.execute("SELECT name FROM groups ORDER BY name").fetchall(); db.close()
    await c.message.edit_text("📚 <b>Guruhlar</b>\n\n"+("\n".join("• "+r["name"] for r in rows) if rows else "Hozircha guruh yo'q."))
    await c.answer()
@router.callback_query(lambda c:c.data=="students")
async def students(c:CallbackQuery):
    db=connect(); rows=db.execute("SELECT s.name,g.name group_name,s.xp,s.coins FROM students s JOIN groups g ON g.id=s.group_id ORDER BY g.name,s.name").fetchall(); db.close()
    text="👥 <b>O'quvchilar</b>\n\n"+("\n".join(f"• {r['name']} — {r['group_name']} — ⭐{r['xp']} XP — 🪙{r['coins']}" for r in rows) if rows else "Hozircha o'quvchi yo'q.")
    await c.message.edit_text(text); await c.answer()
