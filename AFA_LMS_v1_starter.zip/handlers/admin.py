from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message,CallbackQuery
from keyboards import main_menu
router=Router()
@router.message(CommandStart())
async def start(m:Message):
    await m.answer("🏆 <b>AL-FURQON ACADEMY — AFA-LMS v1.0</b>\n\nTugmalar orqali boshqaring.",reply_markup=main_menu())
@router.callback_query(lambda c:c.data=="home")
async def home(c:CallbackQuery):
    await c.message.edit_text("🏠 AFA-LMS",reply_markup=main_menu()); await c.answer()
