from datetime import date
from aiogram import Router
from aiogram.types import CallbackQuery
from database import connect,weighted_score,level_for_xp
router=Router()
def title(s):
    return "👑 MASTER" if s>=95 else "🥇 ELITA" if s>=90 else "🥈 ADVANCED" if s>=80 else "🥉 ACTIVE" if s>=70 else "📚 DEVELOPING" if s>=60 else "🔰 STARTER"
@router.callback_query(lambda c:c.data=="score_menu")
async def score(c:CallbackQuery):
    await c.message.edit_text("📝 Ball kiritish\n\nKeyingi modul: Guruh → O'quvchi → Mezon → Ball tugmalari.")
    await c.answer()
@router.callback_query(lambda c:c.data=="weekly")
async def weekly(c:CallbackQuery):
    w=str(date.today().isocalendar().week); db=connect()
    rows=db.execute("SELECT s.name,w.* FROM weekly_scores w JOIN students s ON s.id=w.student_id WHERE w.week=?",(w,)).fetchall(); db.close()
    ranked=sorted([(r,weighted_score(r)) for r in rows],key=lambda x:x[1],reverse=True)
    text=f"📊 <b>HAFTALIK REYTING — {w}-hafta</b>\n\n"+("\n".join(f"{i}. {r['name']} — {s:.1f}% {title(s)}" for i,(r,s) in enumerate(ranked,1)) if ranked else "Hali natija kiritilmagan.")
    await c.message.edit_text(text); await c.answer()
@router.callback_query(lambda c:c.data=="xp")
async def xp(c:CallbackQuery):
    db=connect(); rows=db.execute("SELECT name,xp FROM students ORDER BY xp DESC").fetchall(); db.close()
    text="⭐ <b>XP / LEVEL</b>\n\n"+("\n".join(f"• {r['name']} — {r['xp']} XP — Lv.{level_for_xp(r['xp'])}" for r in rows) if rows else "Hali o'quvchi yo'q.")
    await c.message.edit_text(text); await c.answer()
@router.callback_query(lambda c:c.data in {"ranking","monthly","attendance","titles","red"})
async def simple(c:CallbackQuery):
    messages={"ranking":"🏆 Reyting","monthly":"📆 Oylik reyting","attendance":"☑️ Davomat","titles":"🏅 Unvonlar","red":"🔴 Muammoli talabalar"}
    await c.message.edit_text(messages[c.data]+"\n\nBu modul keyingi bosqichda to'liq tugmachali qilinadi."); await c.answer()
