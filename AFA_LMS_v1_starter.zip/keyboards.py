from aiogram.types import InlineKeyboardMarkup,InlineKeyboardButton
def main_menu():
    rows=[
    [InlineKeyboardButton(text="📚 Guruhlar",callback_data="groups"),InlineKeyboardButton(text="👥 O'quvchilar",callback_data="students")],
    [InlineKeyboardButton(text="📝 Ball kiritish",callback_data="score_menu"),InlineKeyboardButton(text="☑️ Davomat",callback_data="attendance")],
    [InlineKeyboardButton(text="📊 Haftalik",callback_data="weekly"),InlineKeyboardButton(text="📆 Oylik",callback_data="monthly")],
    [InlineKeyboardButton(text="⭐ XP / Level",callback_data="xp"),InlineKeyboardButton(text="🏆 Reyting",callback_data="ranking")],
    [InlineKeyboardButton(text="🏅 Unvonlar",callback_data="titles"),InlineKeyboardButton(text="🔴 Muammoli talabalar",callback_data="red")]]
    return InlineKeyboardMarkup(inline_keyboard=rows)
