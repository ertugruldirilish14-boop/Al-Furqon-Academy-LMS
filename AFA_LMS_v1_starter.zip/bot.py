import asyncio, os
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher
from database import init_db
from handlers.admin import router as admin_router
from handlers.scores import router as scores_router
from handlers.students import router as students_router

load_dotenv()
TOKEN=os.getenv("BOT_TOKEN")
if not TOKEN: raise RuntimeError("BOT_TOKEN .env faylida yo'q")

async def main():
    init_db()
    bot=Bot(TOKEN)
    dp=Dispatcher()
    dp.include_router(admin_router); dp.include_router(students_router); dp.include_router(scores_router)
    await dp.start_polling(bot)

if __name__=="__main__": asyncio.run(main())
