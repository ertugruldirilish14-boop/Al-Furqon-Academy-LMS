# AFA-LMS v1.0 starter
1. Python 3.11+ o'rnating.
2. `pip install -r requirements.txt`
3. `.env.example` nusxasini `.env` qiling.
4. BOT_TOKEN qatoriga BotFather tokenini o'zingiz kiriting.
5. `python bot.py`
Tokenni hech kimga yubormang.
