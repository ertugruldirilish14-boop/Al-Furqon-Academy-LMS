import sqlite3
from pathlib import Path
DB=Path("afa_lms.db")
def connect():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def init_db():
    c=connect()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS groups(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL);
    CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,group_id INTEGER NOT NULL,tg_id INTEGER UNIQUE,name TEXT NOT NULL,xp INTEGER DEFAULT 0,coins INTEGER DEFAULT 0,FOREIGN KEY(group_id) REFERENCES groups(id));
    CREATE TABLE IF NOT EXISTS weekly_scores(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER NOT NULL,week TEXT NOT NULL,writing REAL DEFAULT 0,vocab REAL DEFAULT 0,grammar REAL DEFAULT 0,reading REAL DEFAULT 0,audio REAL DEFAULT 0,review REAL DEFAULT 0,attendance REAL DEFAULT 0,UNIQUE(student_id,week));
    '''); c.commit(); c.close()
def weighted_score(r):
    return sum(float(r[k])*w for k,w in {"writing":.20,"vocab":.15,"grammar":.15,"reading":.10,"audio":.20,"review":.10,"attendance":.10}.items())
def level_for_xp(xp):
    thresholds=[0,100,220,360,520,700,900,1120,1360,1620]
    level=sum(xp>=x for x in thresholds)
    return max(1,level)
