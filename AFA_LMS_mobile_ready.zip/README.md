# AFA-LMS Mobile Ready

Telegram bot starter for Al-Furqon Academy.

## Ishga tushirish
1. Python 3.11+.
2. `pip install -r requirements.txt`
3. `BOT_TOKEN` environment variable yarating.
4. `python bot.py`

## Muhim
Bot tokenni GitHubga yozmang. Tokenni Render kabi serverda Environment Variables orqali kiriting.

## Haftalik 100 ball
Yozma 20, Lug'at 15, Qoida 15, O'qish 10, Audio 20, Takror 10, Davomat 10.

Bot guruh reytingi, XP va Levelni boshlang'ich darajada hisoblaydi.
