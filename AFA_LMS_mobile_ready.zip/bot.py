import os
import sqlite3
from datetime import datetime
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton

TOKEN = os.getenv("BOT_TOKEN")
DB = "afa_lms.db"

if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing")

bot = Bot(TOKEN)
dp = Dispatcher()

CATEGORIES = {
    "📝 Yozma": 20,
    "📖 Lug'at": 15,
    "📚 Qoida": 15,
    "📣 O'qish": 10,
    "🎙️ Audio": 20,
    "🔁 Takror": 10,
    "☑️ Davomat": 10,
}

def db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE,
        name TEXT NOT NULL,
        xp INTEGER DEFAULT 0,
        coin INTEGER DEFAULT 0
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS scores(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        week TEXT,
        category TEXT,
        score REAL,
        UNIQUE(telegram_id, week, category)
    )""")
    con.commit()
    return con

def menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="👤 Profil"), KeyboardButton(text="📊 Reyting")],
            [KeyboardButton(text="➕ Ball kiritish"), KeyboardButton(text="⭐ XP")],
            [KeyboardButton(text="🏆 Unvonlar"), KeyboardButton(text="❓ Yordam")]
        ],
        resize_keyboard=True
    )

def week_key():
    return datetime.now().strftime("%Y-W%W")

def level(xp):
    levels = [0,100,220,360,520,700,900,1120,1360,1620]
    lv = 1
    for i, need in enumerate(levels, 1):
        if xp >= need:
            lv = i
    return lv

@dp.message(CommandStart())
async def start(m: Message):
    con = db()
    con.execute("INSERT OR IGNORE INTO students(telegram_id,name) VALUES(?,?)",
                (m.from_user.id, m.from_user.full_name))
    con.commit(); con.close()
    await m.answer(
        "🟢 AFA-LMS ga xush kelibsiz!\n\n"
        "Bu botda haftalik ball, XP, level, reyting va unvonlar hisoblanadi.",
        reply_markup=menu()
    )

@dp.message(F.text == "👤 Profil")
async def profile(m: Message):
    con=db()
    row=con.execute("SELECT name,xp,coin FROM students WHERE telegram_id=?",(m.from_user.id,)).fetchone()
    con.close()
    if not row:
        await m.answer("Avval /start bosing."); return
    await m.answer(f"👤 {row[0]}\n⭐ XP: {row[1]}\n🪙 AFA Coin: {row[2]}\n🎮 Level: {level(row[1])}")

@dp.message(F.text == "⭐ XP")
async def xp_cmd(m: Message):
    con=db()
    row=con.execute("SELECT xp,coin FROM students WHERE telegram_id=?",(m.from_user.id,)).fetchone()
    con.close()
    xp, coin = row if row else (0,0)
    await m.answer(f"⭐ XP: {xp}\n🎮 Level: {level(xp)}\n🪙 AFA Coin: {coin}")

@dp.message(F.text == "📊 Reyting")
async def rating(m: Message):
    con=db()
    rows=con.execute("""
      SELECT s.name, COALESCE(SUM(sc.score),0)
      FROM students s LEFT JOIN scores sc
      ON s.telegram_id=sc.telegram_id AND sc.week=?
      GROUP BY s.telegram_id ORDER BY 2 DESC
    """,(week_key(),)).fetchall()
    con.close()
    if not rows:
        await m.answer("Hozircha reyting bo'sh."); return
    text="📊 HAFTALIK REYTING\n\n"
    for i,(name,score) in enumerate(rows,1):
        text += f"{i}. {name} — {score:.0f}/100\n"
    await m.answer(text)

@dp.message(F.text == "➕ Ball kiritish")
async def enter_score(m: Message):
    await m.answer(
        "Ballni kiritish formati:\n\n"
        "📝 Yozma 18\n"
        "📖 Lug'at 14\n"
        "📚 Qoida 15\n"
        "📣 O'qish 9\n"
        "🎙️ Audio 20\n"
        "🔁 Takror 10\n"
        "☑️ Davomat 10\n\n"
        "Har bir ko'rsatkich o'z maksimal foizidan oshmasin."
    )

@dp.message(F.text == "🏆 Unvonlar")
async def titles(m: Message):
    await m.answer(
        "🏆 AFA UNVONLARI\n\n"
        "🥉 Bronze — 1 hafta 90+\n"
        "🥈 Silver — 4 hafta 90+\n"
        "🥇 Gold — 3 oy yuqori natija\n"
        "💎 Diamond — 6 oy yuqori natija\n"
        "👑 Royal — 1 yil namunali natija"
    )

@dp.message(F.text == "❓ Yordam")
async def help_cmd(m: Message):
    await m.answer(
        "❓ Yordam\n\n"
        "/start — profilni yaratish\n"
        "➕ Ball kiritish — haftalik natijalarni yuborish\n"
        "📊 Reyting — guruh reytingi\n"
        "⭐ XP — umrboqiy tajriba\n"
        "🏆 Unvonlar — darajalar"
    )

@dp.message()
async def score_message(m: Message):
    if not any(k in m.text for k in CATEGORIES):
        return
    con=db()
    con.execute("INSERT OR IGNORE INTO students(telegram_id,name) VALUES(?,?)",
                (m.from_user.id, m.from_user.full_name))
    total=0; changed=0
    for line in m.text.splitlines():
        parts=line.rsplit(" ",1)
        if len(parts)!=2: continue
        cat,val=parts
        if cat not in CATEGORIES: continue
        try: val=float(val)
        except: continue
        if 0 <= val <= CATEGORIES[cat]:
            con.execute("""INSERT INTO scores(telegram_id,week,category,score)
                           VALUES(?,?,?,?)
                           ON CONFLICT(telegram_id,week,category)
                           DO UPDATE SET score=excluded.score""",
                        (m.from_user.id,week_key(),cat,val))
            total += val; changed += 1
    # XP is granted only once when weekly total reaches 90 or 100.
    rows=con.execute("SELECT category,score FROM scores WHERE telegram_id=? AND week=?",
                     (m.from_user.id,week_key())).fetchall()
    weekly=sum(x[1] for x in rows)
    xp_add=0
    if weekly >= 90:
        xp_add += 20
    if weekly >= 100:
        xp_add += 40
    if xp_add:
        marker = f"{week_key()}_{m.from_user.id}_{xp_add}"
        con.execute("CREATE TABLE IF NOT EXISTS xp_marks(marker TEXT PRIMARY KEY)")
        if con.execute("SELECT 1 FROM xp_marks WHERE marker=?",(marker,)).fetchone() is None:
            con.execute("INSERT INTO xp_marks VALUES(?)",(marker,))
            con.execute("UPDATE students SET xp=xp+? WHERE telegram_id=?",(xp_add,m.from_user.id))
    con.commit(); con.close()
    if changed:
        await m.answer(f"✅ Saqlandi!\n📊 Haftalik ball: {weekly:.0f}/100\n⭐ Qo'shilgan XP: {xp_add}", reply_markup=menu())

if __name__ == "__main__":
    db()
    dp.run_polling(bot)
